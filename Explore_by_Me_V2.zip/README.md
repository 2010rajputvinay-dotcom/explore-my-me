# Explore by Me V2
Mobile-first communication website prototype.

## GitHub Pages
1. Create a public GitHub repository.
2. Upload `index.html`.
3. Settings -> Pages -> Deploy from branch -> `main` -> `/ (root)`.
4. Open the generated GitHub Pages URL.

## Firebase
The UI is prepared for Firebase integration, but Firebase credentials and backend rules are intentionally not included. Add Firebase Authentication, Firestore, and security rules before enabling real accounts or messaging.
